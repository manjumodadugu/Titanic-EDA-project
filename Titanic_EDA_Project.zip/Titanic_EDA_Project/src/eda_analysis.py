import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

DATA_URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
OUT_DIR = Path("visualizations")
OUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_URL)

print("\n--- HEAD ---")
print(df.head())

print("\n--- INFO ---")
df.info()

print("\n--- DESCRIBE ---")
print(df.describe(include="all").T)

print("\n--- MISSING VALUES ---")
print(df.isnull().sum())

print("\n--- DUPLICATES ---")
print("Duplicate rows:", df.duplicated().sum())

# Data cleaning
df_clean = df.copy()
df_clean["Age"] = df_clean["Age"].fillna(df_clean["Age"].median())
df_clean["Embarked"] = df_clean["Embarked"].fillna(df_clean["Embarked"].mode()[0])
df_clean = df_clean.drop_duplicates()

print("\n--- CLEANED DATA ---")
print("Rows before:", len(df))
print("Rows after :", len(df_clean))
print("Remaining missing values:")
print(df_clean.isnull().sum())

# Grouping and aggregation
print("\n--- SURVIVAL BY GENDER ---")
print(df_clean.groupby("Sex")["Survived"].agg(["count", "sum", "mean"]))

print("\n--- SURVIVAL BY CLASS ---")
print(df_clean.groupby("Pclass")["Survived"].agg(["count", "sum", "mean"]))

print("\n--- FARE STATISTICS BY CLASS ---")
print(df_clean.groupby("Pclass")["Fare"].agg(["mean", "median", "min", "max"]))

# Visualizations
sns.set_theme(style="whitegrid")

plt.figure(figsize=(8, 5))
sns.countplot(data=df_clean, x="Survived")
plt.title("Survival Count")
plt.savefig(OUT_DIR / "survival_count.png", bbox_inches="tight")
plt.close()

plt.figure(figsize=(8, 5))
sns.barplot(data=df_clean, x="Sex", y="Survived")
plt.title("Survival Rate by Gender")
plt.ylabel("Survival Rate")
plt.savefig(OUT_DIR / "survival_by_gender.png", bbox_inches="tight")
plt.close()

plt.figure(figsize=(8, 5))
sns.barplot(data=df_clean, x="Pclass", y="Survived")
plt.title("Survival Rate by Passenger Class")
plt.ylabel("Survival Rate")
plt.savefig(OUT_DIR / "survival_by_class.png", bbox_inches="tight")
plt.close()

plt.figure(figsize=(8, 5))
sns.histplot(data=df_clean, x="Age", bins=30, kde=True)
plt.title("Age Distribution")
plt.savefig(OUT_DIR / "age_distribution.png", bbox_inches="tight")
plt.close()

plt.figure(figsize=(8, 5))
sns.histplot(data=df_clean, x="Fare", bins=30, kde=True)
plt.title("Fare Distribution")
plt.savefig(OUT_DIR / "fare_distribution.png", bbox_inches="tight")
plt.close()

numeric_cols = ["Survived", "Pclass", "Age", "SibSp", "Parch", "Fare"]
plt.figure(figsize=(9, 6))
sns.heatmap(df_clean[numeric_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Matrix")
plt.savefig(OUT_DIR / "correlation_heatmap.png", bbox_inches="tight")
plt.close()

print("\nEDA completed. Charts saved in the visualizations/ folder.")
