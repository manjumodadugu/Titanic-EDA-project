# Dataset

The notebook downloads the Titanic dataset automatically from:

https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv

This keeps the GitHub repository lightweight. If you want the CSV stored locally, download it and save it here as `titanic.csv`.
